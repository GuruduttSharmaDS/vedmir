<script>
	var DASHURL		= '<?php echo DASHURL; ?>';
	var DASHSTATIC	= '<?php echo DASHSTATIC; ?>';
	var BASEURL		= '<?php echo BASEURL; ?>';
	var UPLOADPATH	= '<?php echo UPLOADPATH; ?>';
	var GLOBALLANG = <?php echo json_encode($this->lang->language);?>;
</script>