
        </div>
      </div>
    </div>
    <!-- /#page-content-wrapper -->
  </div>
  <!-- /#wrapper -->

  <!-- Menu Toggle Script -->
  <script type="text/javascript" src="<?=DASHSTATIC?>/js/jquery.min.js"></script>
  <script type="text/javascript" src="<?=DASHSTATIC?>/js/popper.min.js"></script>
  <script type="text/javascript" src="<?=DASHSTATIC?>/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="<?=DASHSTATIC?>/js/mdb.min.js"></script>
  <script type="text/javascript" src="<?=DASHSTATIC?>/js/custom.js"></script>
  <script type="text/javascript" src="<?=DASHSTATIC?>/js/validate.js"></script>
  <script type="text/javascript" src="<?=DASHSTATIC?>/js/admin.js"></script>