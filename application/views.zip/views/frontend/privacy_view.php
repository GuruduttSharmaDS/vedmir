
<?php include 'inc/header.php';?>
 <style>
.privacy_page h1 {
    font-size: 30px;
    text-transform: uppercase;
    color: #000;
    text-align: center;
    margin-bottom: 50px;
    margin-top: 100px;
}
.privacy_page h2 {
    font-size: 20px;
    margin-bottom: 20px;
}
.privacy_page p {
    font-size: 16px;
    margin-bottom: 20px;
    color: #000;
    font-weight: 400;
}
.information {
  
}
.information li {
    color: #000;
    font-weight: 400;
}
</style>
<div class="privacy_page">
    <div class="container">
<?php if($this->sessLang == 'french'){  ?>
          <h1>Politique de confidentialité</h1>
        <h2>Information Collection And Use</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, quis efficitur massa egestas ut. Praesent sit amet lorem maximus, interdum purus at, placerat nisl. Praesent sed suscipit turpis. Morbi maximus tempus sem, sit amet lobortis quam.</p>
        <h2>Log Data</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus,
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, quis efficitur massa egestas ut. Praesent sit amet lorem maximus, interdum purus at, placerat nisl. Praesent sed suscipit turpis. Morbi maximus tempus sem, sit amet lobortis quam.
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, 
        </p>
        <h2>We may collect the following information:</h2>
        <ul class="information">
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            
        </ul>
        <h2>We may collect the following information:</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, </p>
        <ul class="information">
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            
        </ul>
        <h2>Security</h2>
        <p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness.  </p>
        <h2>How we use</h2>
        <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, </p>

<?php }else if($this->sessLang == 'german'){  ?>
          <h1>Datenschutz-Bestimmungen</h1>
        <h2>Information Collection And Use</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, quis efficitur massa egestas ut. Praesent sit amet lorem maximus, interdum purus at, placerat nisl. Praesent sed suscipit turpis. Morbi maximus tempus sem, sit amet lobortis quam.</p>
        <h2>Log Data</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus,
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, quis efficitur massa egestas ut. Praesent sit amet lorem maximus, interdum purus at, placerat nisl. Praesent sed suscipit turpis. Morbi maximus tempus sem, sit amet lobortis quam.
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, 
        </p>
        <h2>We may collect the following information:</h2>
        <ul class="information">
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            
        </ul>
        <h2>We may collect the following information:</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, </p>
        <ul class="information">
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            
        </ul>
        <h2>Security</h2>
        <p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness.  </p>
        <h2>How we use</h2>
        <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, </p>

<?php }else if($this->sessLang == 'italian'){  ?>
<h1>politica sulla riservatezza</h1>
        <h2>Information Collection And Use</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, quis efficitur massa egestas ut. Praesent sit amet lorem maximus, interdum purus at, placerat nisl. Praesent sed suscipit turpis. Morbi maximus tempus sem, sit amet lobortis quam.</p>
        <h2>Log Data</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus,
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, quis efficitur massa egestas ut. Praesent sit amet lorem maximus, interdum purus at, placerat nisl. Praesent sed suscipit turpis. Morbi maximus tempus sem, sit amet lobortis quam.
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, 
        </p>
        <h2>We may collect the following information:</h2>
        <ul class="information">
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            
        </ul>
        <h2>We may collect the following information:</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, </p>
        <ul class="information">
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            
        </ul>
        <h2>Security</h2>
        <p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness.  </p>
        <h2>How we use</h2>
        <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, </p>

<?php }else { ?>
          <h1>Privacy Policy</h1>
        <h2>Information Collection And Use</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, quis efficitur massa egestas ut. Praesent sit amet lorem maximus, interdum purus at, placerat nisl. Praesent sed suscipit turpis. Morbi maximus tempus sem, sit amet lobortis quam.</p>
        <h2>Log Data</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus,
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, quis efficitur massa egestas ut. Praesent sit amet lorem maximus, interdum purus at, placerat nisl. Praesent sed suscipit turpis. Morbi maximus tempus sem, sit amet lobortis quam.
        </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, 
        </p>
        <h2>We may collect the following information:</h2>
        <ul class="information">
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            
        </ul>
        <h2>We may collect the following information:</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sodales suscipit erat non congue. Curabitur dignissim eros metus, </p>
        <ul class="information">
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            
        </ul>
        <h2>Security</h2>
        <p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness.  </p>
        <h2>How we use</h2>
        <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, </p>

<?php }  ?>

        
    </div>
</div>


<?php include 'inc/footer.php';?>