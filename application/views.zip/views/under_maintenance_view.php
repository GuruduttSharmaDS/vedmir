<!DOCTYPE html>
<html lang="en">
<head>
  <title>Vedmir</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body style="background: url(<?=BASEURL; ?>/system/static/bg-61.jpg) no-repeat center;">
  
<div class="container" >
<div class="row">
<div class="col-md-12">
  
            <h1 style="color: white; font-weight: 700;">We are currently working on something awesome. Stay tuned!</h1>
            <h4 style="color: white; ">Sorry for the inconvenience but we&rsquo;re performing some maintenance at the moment. If you need to you can always <a href="mailto:thatsvivek007@gmail.com">contact us</a>, otherwise we&rsquo;ll be back online shortly!</h4>
        <h4 style="color: white; ">&mdash; Development Team</h4>          
</div>          
</div>          
</div>

</body>
</html>
